<?php

    defined('BASEPATH') OR exit('No direct script access allowed');

    class HomeModel extends CI_model 
    {
        
        public function quetions()
        {
            //SELECT `id`, `title`, `user_id`, `video`, `description`, `vote`, `view`, `answer`, `created_at`, `updated_at` FROM `quetions` WHERE 1
            //SELECT `id`, `name`, `email`, `pwd`, `checkme`, `created_at`, `updated_at` FROM `signup` WHERE 1
            $query = $this->db->select('q.id, q.title, q.user_id, q.video, q.description, q.vote, q.view, q.answer, q.created_at, q.updated_at, s.name')
            ->from('quetions as q')
            //->where('t1.id', $id)
            ->join('signup as s', 'q.user_id = s.id', 'LEFT')
            //->join('table3 as t3', 't1.id = t3.id', 'LEFT')
            ->get();
            return $query->result_array();
        }
        
        public function insert_data($table_name, $array_data) 
        {
            return $this->db->insert($table_name, $array_data);
        }
        
        
        public function select_cond_data($table_name, $array_data)
        {
            $query = $this->db->select('*')
		         ->from($table_name)
		         ->where($array_data)
		         ->get();
		         
            return $query->result_array();
        }
        
        public function getall($table_name)
        {
            //SELECT * FROM `quetions`
            $query = $this->db->select('*')
		         ->from($table_name)
		        
		         ->get();
		         
            return $query->result_array();
            //print_r($this->db->last_query());
        }    


		
    }
