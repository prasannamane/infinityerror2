<div class="col-md-3 col-sm-3">
        <div class="last-bar">
            <div class="panel panel-warning">
    <div class="panel-heading">The Overflow Blog</div>
    <div class="panel-body panel-body-new-one">
        <ul>
            <li>
        <p>Postcast - 25 Years of java the past to the present</p></li>
        <li><p>Java at 25 : Features that made an impact and a look to the future</p></li>
        </ul>
  </div>
  <div class="panel-heading">Feature Media</div>
  <div class="panel-body">
      <ul class="list-unstyle">
      <li>
          <div class="checkbox">
  <label><input type="checkbox" value="">improve experience for user with review sudpensions</label>
</div>
</li>
<li>
<div class="checkbox">
  <label><input type="checkbox" value="">CEO Blog Some exciting news about fundrqising</label>
</div>
</li>
 
      </ul>
      </li>
      
  </div>
            
        </div>
        
    </div>
    </div>
    


</div>
</div>