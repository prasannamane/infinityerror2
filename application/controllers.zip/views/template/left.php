<div class="container-fluid padding-page-top">
    <div class="row">
        <div class="col-md-2 col-sm-2 b-right">
            <div class="row">
                <div class="sidebar">
                    <ul>
                        <li><a href="#" class="active-nav">Home</a></li>
                        <li><a href="#">Public</a>
                        <ul class="padd-left">
                        <li><a href="#">Stack Overflow</a></li>
                        <li><a href="#">Users</a></li>
                        </ul>
                        </li>
                        <li><a href="#">Find a job</a>
                        <ul>
                        <li><a ref="#">Job</a></li>
                        <li><a href="#">Companies</a></li>
                        </ul>
                        </li>
                        <li><a href="#">Team<span class="float-right">What's This?</span> </a></li>
                    </ul>
                </div>
            </div>
        </div>