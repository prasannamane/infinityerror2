<footer>
    <div class="container">
        <div class="row">
        <div class="col-md-8 col-sm-8">
            <div class="row">
                 <div class="col-md-3 col-sm-3">
                      <h3>Stack Overflow</h3>
                      <ul>
                          <li><a href="#">Questions</a></li>
                          <li><a href="#">Jobs</a></li>
                          <li><a href="#">Developer Jobs Directory</a></li>
                          <li><a href="#">Salary Calculator</a></li>
                          <li><a href="#">Help</a></li>
                          <li><a href="#">Mobile</a></li>
                          <li><a href="#">Disable Responsiveness</a></li>
                      </ul>
                 </div>
                 
                 <div class="col-md-3 col-sm-3">
                      <h3>PRODUCTS</h3>
                      <ul>
                          <li><a href="#">Terms</a></li>
                          <li><a href="#">Talent</a></li>
                          <li><a href="#">Advertising</a></li>
                          <li><a href="#">Enterprise</a></li>
                      </ul>
                 </div>
                 
                 
                 <div class="col-md-3 col-sm-3">
                      <h3>COMPANY</h3>
                      <ul>
                          <li><a href="#">About</a></li>
                          <li><a href="#">Press</a></li>
                          <li><a href="#">Work Here</a></li>
                          <li><a href="#">Legal </a></li>
                          <li><a href="#">Privacy Policy</a></li>
                          <li><a href="#">Contact Us</a></li>
                      </ul>
                 </div>
                 
                 
                 <div class="col-md-3 col-sm-3">
                      <h3>STACK EXCHANGE NETWORK</h3>
                      <ul>
                          <li><a href="#">Technology</a></li>
                          <li><a href="#">Life / Arts</a></li>
                          <li><a href="#">Culture / Recreation</a></li>
                          <li><a href="#">Science </a></li>
                          <li><a href="#">Other</a></li>
                      </ul>
                 </div>
                
            </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <ul class="list-inline">
                    <li><a href="#">Blog</a></li>
                     <li><a href="#">Facebook</a></li>
                      <li><a href="#">Twittter</a></li>
                       <li><a href="#">LinkedIn</a></li>
                        <li><a href="#">Instagram</a></li>
                </ul>
                
            </div>
            
        </div>
        </div>
        
    </div>
</footer>
</html>
