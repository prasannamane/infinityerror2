
<div class="main-page">
    <div class="container">
	    <div class="col-md-6 right-main max-auto">
	        <div class="right-main-inner">
	            <div class="row">
		            <div class="">
                        <form>
                            <div class="form-group">
                                <label for="name">Forgot your account’s password or having trouble logging into your Team? Enter your email address and we’ll send you a recovery link.</label>
                                
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                            </div>
                            <button type="submit" name="Send recovery email"  class="btn btn-info sign-up-btn-form btn-block">Send recovery email </button>
                        </form>
                    </div>
		        </div>
		    </div>
	    </div>
	</div>
</div>