
    <div class="col-md-7 col-sm-7 border-bottom">
        <div class="row">
        <div class="middle-bar">
            <div class="m-bar-first">
            <div class="middle-bar-left">
                 <h2>Queries for You</h2>
            </div>
             <div class="middle-bar-right">
                  <button class="btn btn-info">Ask Question</button>
                
            </div>
            </div>
            
            <div class="tab-top">
                <div class="tab-top-ul">
                    <ul class="list-inline">
                        <li><a href="#">Interesting</a></li>
                        <li><a href="#">Bountied</a></li>
                        <li><a href="#">Hot</a></li>
                        <li><a href="#">Week</a></li>
                        <li><a href="#">Month</a></li>
                    </ul>
                    
                </div>
                
            </div>
            <div class="col-md-12">
                <div class="row">
                    <form>
                        <div class="col-md-12">
                            <div class="row">
                           <div class="form-group">
                             <label>Title</label>
                              <input type="text" name="your question" class="form-control" requred>
                           </div>
                           </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                           <div class="form-group">
                             <label>Discriobtion</label>
                              <textarea class="form-control custum-textarea"></textarea>
                           </div>
                           </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                           <div class="form-group">
                             <label>Your Question</label>
                              <input type="text" name="your question" class="form-control" requred>
                           </div>
                           </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                           <div class="form-group">
                             <label>Upload Video</label>
                              <input type="file" name="uplad video" class="form-control" requred>
                           </div>
                           </div>
                        </div>
                        <div class="col-md-12">
                            <div class="row">
                           <div class="form-group">
                             <label>select tags</label>
                              <select class="selectpicker form-control">
                                 <optgroup>
                                       <option>demo1</option>
                                       <option>demo2</option>
                                       <option>demo3</option>
                                 </optgroup>
                              </select>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-12 text-center">
                             <div class="submit-btn btn btn-info text-uppercase">submit question</div>
                        </div>
                                            </form>
                    
                </div>
                
            </div>
            
        </div>
    </div>
</div>
    
   