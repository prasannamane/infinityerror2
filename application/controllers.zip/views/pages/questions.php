<div class="col-md-7 col-sm-7 border-bottom">
    <div class="row">
<div class="">
	<div class="col-md-12 bgbb">
	   <div class="">
	   <div class="m-bar-first m-bar-first-new">
            <div class="middle-bar-left">
                 <h2>Common method for logging in Spring-boot</h2>
				 <p>Asked <span class="font-weight-bold">Today</span>&nbsp &nbsp Active <span class="font-weight-bold">Today</span>&nbsp &nbsp Viewed <span class="font-weight-bold">5 Times</span></p>
            </div>
             <div class="middle-bar-right">
                  <button class="btn btn-info">Ask Question</button>
                
            </div>
            </div>
			</div>
	</div>
	<div class="middle-bar middle-bar-question">
    <div class="col-md-12 border-bottom">
        <div class="row">
		   <div class="question-middle">
		      <h6>Here is controller class for GetMapping and PostMapping</h6>
            </div>
             <div class="code-img">
			      
			      <video width="100%" controls>
                      <source src="https://bedkihal.com/projects.com/infinityerror2/assets/errorvideo/demo.mp4" type="video/mp4" class="img-responsive">
                 </video>

				  
			 </div>
			 <div class="hr hr-new">
			     <hr/>
			     
			 </div>
			 <div class="form-group">
			     <textarea class="form-control text-area-new">
			         
			     </textarea>
			     
			 </div>

           		   
        
        </div>
        </div>
        
    </div>
    </div>
    </div>
    
    
    </div>