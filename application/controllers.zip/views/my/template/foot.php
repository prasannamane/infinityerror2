	</div>
	<div class="go-up" style="right: -60px;">
	    <i class="icon-chevron-up"></i>
    </div> 
    <script type="text/javascript">
        jQuery(document).ready(function() 
        {
	        jQuery('#live-search #s').liveSearch({url: 'https://fluentthemes.com/wp/knowledge/index.php?ajax=1&s='});
	    });
    </script> 
    <script type="text/javascript">
    /* <![CDATA[ */ 
    var wpcf7 = { "apiSettings":{"root":"https:\/\/fluentthemes.com\/wp\/knowledge\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"}; /* ]]> */</script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/scripts-503381e5ab2551094d0694d5b341a4be.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/html5-1b2b3b1056b21205c3484025abef71d7.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/modernizr-a5b6e305c693e9f398f010c6a5fc1ccb.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.tipsy-03cdc48274aad6384a95ebd87799c431.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/tabs-fbf521237bed24b79f165ec22f4bbeeb.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.prettyPhoto-a9b8f98a93b9f17f944605a709de82bb.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.scrollTo-189f0dd1451d5b97ad2a726c1e3e80f3.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.nav-3ce4ddbb9b7b2982a579c4ca7713c84e.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/tags-48c0d8805c110752442e1c9aa079a2fb.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/bootstrap.min.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.countTo-d423c354c33f40affb99e7a5b5072d5f.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.waypoints-dcd427bbb3f9c62b0d9598de9b23d388.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/carousel.min.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/jquery.stellar.min.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/bootstrap-dropdownhover.min.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/shCore-bdc9dcc363e96c825152da834f9337a5.js')?>">
    </script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/shBrushPhp-4c31b46cc226024ca486f6c075ad71cc.js')?>">
    </script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/core.min.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/widget.min.js')?>">
    </script> <script type="text/javascript" src="<?=base_url('myassets/js/mouse.min.js')?>"></script> 
    <script type="text/javascript" src="<?=base_url('myassets/js/sortable.min.js')?>"></script> 
    <script type="text/javascript">
        /* <![CDATA[ */ 
    var template_url = "https:\/\/fluentthemes.com\/wp\/knowledge\/wp-content\/themes\/infocenter";
    var products_excerpt_title = [""];
    var go_to = "Go to...";
    var ask_error_text = "Please fill the required field.";
    var ask_error_captcha = "The captcha is incorrect, please try again.";
    var captcha_answer = "Cairo";
    var add_question = "https:\/\/fluentthemes.com\/wp\/knowledge\/add-question\/";
    var ask_error_empty = "Fill in all the required fields.";
    var no_vote_more = "Sorry, you cannot vote on the same Question more than once.";
    var no_vote_user = "Rating is available to members only.";
    var no_vote_more_comment = "Sorry, you cannot vote on the same comment more than once.";
    var v_get_template_directory_uri = "https:\/\/fluentthemes.com\/wp\/knowledge\/wp-content\/themes\/infocenter";
    var sure_report = "Are you sure you want to Report?";
    var sure_delete = "Are you sure you want to delete the Question?";  
    var sure_delete_post = "Are you sure you want to delete the post?";
    var reported_question = "We are reported for the Question!";
    var choose_best_answer = "Select as Best Answer";
    var cancel_best_answer = "Cancel the Best Answer";
    var best_answer = "Best Answer";
    var follow_question_attr = "Follow the Question";
    var unfollow_question_attr = "Unfollow the Question";
    var follow_question = "Follow";
    var unfollow_question = "Unfollow";
    var admin_url = "https:\/\/fluentthemes.com\/wp\/knowledge\/wp-admin\/admin-ajax.php";
    var select_file = "Select file";
    var browse = "Browse";
    var question_tab = "fluentthemes.com"; 
    /* ]]> */
    </script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/custom-owl-5f594c374c2f9765b0203d2a4e4cceff.js')?>"></script> 
    <script data-minify="1" type="text/javascript" src="<?=base_url('myassets/js/jquery.livesearch-4d4759d5eab477bc33d17408a80777bd.js')?>"></script>
    <script>window.lazyLoadOptions={elements_selector:"img[data-lazy-src],.rocket-lazyload",data_src:"lazy-src",data_srcset:"lazy-srcset",data_sizes:"lazy-sizes",class_loading:"lazyloading",class_loaded:"lazyloaded",threshold:300,callback_loaded:function(element){if(element.tagName==="IFRAME"&&element.dataset.rocketLazyload=="fitvidscompatible"){if(element.classList.contains("lazyloaded"))
    {
        if(typeof window.jQuery!="undefined"){if(jQuery.fn.fitVids){jQuery(element).parent().fitVids()}}}}}};window.addEventListener('LazyLoad::Initialized',function(e){var lazyLoadInstance=e.detail.instance;if(window.MutationObserver){
            var observer=new MutationObserver(function(mutations){var image_count=0;var iframe_count=0; var rocketlazy_count=0;mutations.forEach(function(mutation){
                for(i=0;i<mutation.addedNodes.length;i++){if(typeof mutation.addedNodes[i].getElementsByTagName!=='function'){return}
if(typeof mutation.addedNodes[i].getElementsByClassName!=='function'){return}
images=mutation.addedNodes[i].getElementsByTagName('img');is_image=mutation.addedNodes[i].tagName=="IMG";
iframes=mutation.addedNodes[i].getElementsByTagName('iframe');is_iframe=mutation.addedNodes[i].tagName=="IFRAME";
rocket_lazy=mutation.addedNodes[i].getElementsByClassName('rocket-lazyload');image_count+=images.length;iframe_count+=iframes.length;rocketlazy_count+=rocket_lazy.length;
if(is_image){image_count+=1}
if(is_iframe){iframe_count+=1}}});if(image_count>0||iframe_count>0||rocketlazy_count>0){lazyLoadInstance.update()}});
var b=document.getElementsByTagName("body")[0];var config={childList:!0,subtree:!0};observer.observe(b,config)}},!1)</script>
<script data-no-minify="1" async="" src="<?=base_url('myassets/js/lazyload.min.js')?>"></script> 
<!-- This website is like a Rocket, isn't it? Performance optimized by WP Rocket. Learn more: https://wp-rocket.me - Debug: cached@1596823630 --><div id="jquery-live-search" style="display: none;">
	
</div>
</body>
</html>