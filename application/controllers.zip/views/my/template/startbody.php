<body class="home page-template page-template-template-home page-template-template-home-php page page-id-13 wp-embed-responsive" data-gr-c-s-loaded="true">
	<div class="background-cover">
	
</div>
<div class="loader" style="display: none;">
	<div class="loader_html">
		
	</div>
</div>
<div class="infocenter-panel-pop" id="signup">
	<h2>Register Now<i class="icon-remove"></i></h2>
	<div class="form-style form-style-3">
	    <form method="post" class="signup_form ask_form" enctype="multipart/form-data" action="<?=base_url('Home/signin')?>">
	        <div class="ask_error"></div>
	        <div class="form-inputs clearfix">
	            <p>
	                <label for="user_name_981" class="required">Username<span>*</span></label> 
	                <input type="text" class="required-item" name="name" id="user_name_981" value="" required>
	            </p>
			    <p> 
			        <label for="email_981" class="required">E-Mail<span>*</span></label> 
			        <input type="email" class="required-item" name="email" id="email_981" value="" required>
			    </p>
			    <p> 
    			    <label for="pass1_981" class="required">Password<span>*</span></label>
    			    <input type="password" class="required-item" name="pwd" id="pass1_981" autocomplete="off" required>
    		    </p>
			    <p> 
    			 	<label for="pass2_981" class="required">Confirm Password<span>*</span></label> 
    			 	<input type="password" class="required-item" name="pass2" id="pass2_981" autocomplete="off" required>
    		    </p>
<!--			 	<label for="attachment_981">Profile Picture</label>
			 	    <div class="fileinputs">
			            <input type="file" name="you_avatar" id="attachment_981" required>
			                <div class="fakefile"> 
			                    <button type="button" class="small margin_0">Select file</button> 
			                    <span><i class="icon-arrow-up"></i>Browse</span>
			                </div>
			         </div>-->
	<!--		         <p> 
			  	        <label for="country_981">Country</label> 
			  	        <span class="styled-select">
			  	            <select name="country" id="country_981">
			  		            <option value="">Select a country…</option>
			  	                <option value="AX">Åland Islands</option>
			  	                <option value="AF">Afghanistan</option>
			  	                <option value="AL">Albania</option>
			  	                <option value="DZ">Algeria</option><option value="AD">Andorra</option><option value="AO">Angola</option><option value="AI">Anguilla</option><option value="AQ">Antarctica</option><option value="AG">Antigua and Barbuda</option><option value="AR">Argentina</option><option value="AM">Armenia</option><option value="AW">Aruba</option><option value="AU">Australia</option><option value="AT">Austria</option><option value="AZ">Azerbaijan</option><option value="BS">Bahamas</option><option value="BH">Bahrain</option><option value="BD">Bangladesh</option><option value="BB">Barbados</option><option value="BY">Belarus</option><option value="PW">Belau</option><option value="BE">Belgium</option><option value="BZ">Belize</option><option value="BJ">Benin</option><option value="BM">Bermuda</option><option value="BT">Bhutan</option><option value="BO">Bolivia</option><option value="BQ">Bonaire, Saint Eustatius and Saba</option><option value="BA">Bosnia and Herzegovina</option><option value="BW">Botswana</option><option value="BV">Bouvet Island</option><option value="BR">Brazil</option><option value="IO">British Indian Ocean Territory</option><option value="VG">British Virgin Islands</option><option value="BN">Brunei</option><option value="BG">Bulgaria</option><option value="BF">Burkina Faso</option><option value="BI">Burundi</option><option value="KH">Cambodia</option><option value="CM">Cameroon</option><option value="CA">Canada</option><option value="CV">Cape Verde</option><option value="KY">Cayman Islands</option><option value="CF">Central African Republic</option><option value="TD">Chad</option><option value="CL">Chile</option><option value="CN">China</option><option value="CX">Christmas Island</option><option value="CC">Cocos (Keeling) Islands</option><option value="CO">Colombia</option><option value="KM">Comoros</option><option value="CG">Congo (Brazzaville)</option><option value="CD">Congo (Kinshasa)</option><option value="CK">Cook Islands</option><option value="CR">Costa Rica</option><option value="HR">Croatia</option><option value="CU">Cuba</option><option value="CW">CuraÇao</option><option value="CY">Cyprus</option><option value="CZ">Czech Republic</option><option value="DK">Denmark</option><option value="DJ">Djibouti</option><option value="DM">Dominica</option><option value="DO">Dominican Republic</option><option value="EC">Ecuador</option><option value="EG">Egypt</option><option value="SV">El Salvador</option><option value="GQ">Equatorial Guinea</option><option value="ER">Eritrea</option><option value="EE">Estonia</option><option value="ET">Ethiopia</option><option value="FK">Falkland Islands</option><option value="FO">Faroe Islands</option><option value="FJ">Fiji</option><option value="FI">Finland</option><option value="FR">France</option><option value="GF">French Guiana</option><option value="PF">French Polynesia</option><option value="TF">French Southern Territories</option><option value="GA">Gabon</option><option value="GM">Gambia</option><option value="GE">Georgia</option><option value="DE">Germany</option><option value="GH">Ghana</option><option value="GI">Gibraltar</option><option value="GR">Greece</option><option value="GL">Greenland</option><option value="GD">Grenada</option><option value="GP">Guadeloupe</option><option value="GT">Guatemala</option><option value="GG">Guernsey</option><option value="GN">Guinea</option><option value="GW">Guinea-Bissau</option><option value="GY">Guyana</option><option value="HT">Haiti</option><option value="HM">Heard Island and McDonald Islands</option><option value="HN">Honduras</option><option value="HK">Hong Kong</option><option value="HU">Hungary</option><option value="IS">Iceland</option><option value="IN">India</option><option value="ID">Indonesia</option><option value="IR">Iran</option><option value="IQ">Iraq</option><option value="IM">Isle of Man</option><option value="IL">Israel</option><option value="IT">Italy</option><option value="CI">Ivory Coast</option><option value="JM">Jamaica</option><option value="JP">Japan</option><option value="JE">Jersey</option><option value="JO">Jordan</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KI">Kiribati</option><option value="KW">Kuwait</option><option value="KG">Kyrgyzstan</option><option value="LA">Laos</option><option value="LV">Latvia</option><option value="LB">Lebanon</option><option value="LS">Lesotho</option><option value="LR">Liberia</option><option value="LY">Libya</option><option value="LI">Liechtenstein</option><option value="LT">Lithuania</option><option value="LU">Luxembourg</option><option value="MO">Macao S.A.R., China</option><option value="MK">Macedonia</option><option value="MG">Madagascar</option><option value="MW">Malawi</option><option value="MY">Malaysia</option><option value="MV">Maldives</option><option value="ML">Mali</option><option value="MT">Malta</option><option value="MH">Marshall Islands</option><option value="MQ">Martinique</option><option value="MR">Mauritania</option><option value="MU">Mauritius</option><option value="YT">Mayotte</option><option value="MX">Mexico</option><option value="FM">Micronesia</option><option value="MD">Moldova</option><option value="MC">Monaco</option><option value="MN">Mongolia</option><option value="ME">Montenegro</option><option value="MS">Montserrat</option><option value="MA">Morocco</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NA">Namibia</option><option value="NR">Nauru</option><option value="NP">Nepal</option><option value="NL">Netherlands</option><option value="AN">Netherlands Antilles</option><option value="NC">New Caledonia</option><option value="NZ">New Zealand</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nigeria</option><option value="NU">Niue</option><option value="NF">Norfolk Island</option><option value="KP">North Korea</option><option value="NO">Norway</option><option value="OM">Oman</option>
	<option value="PK">Pakistan</option><option value="PS">Palestinian Territory</option><option value="PA">Panama</option><option value="PG">Papua New Guinea</option><option value="PY">Paraguay</option><option value="PE">Peru</option><option value="PH">Philippines</option><option value="PN">Pitcairn</option><option value="PL">Poland</option><option value="PT">Portugal</option><option value="QA">Qatar</option><option value="IE">Republic of Ireland</option><option value="RE">Reunion</option><option value="RO">Romania</option><option value="RU">Russia</option><option value="RW">Rwanda</option><option value="ST">São Tomé and Príncipe</option><option value="BL">Saint Barthélemy</option><option value="SH">Saint Helena</option><option value="KN">Saint Kitts and Nevis</option><option value="LC">Saint Lucia</option><option value="SX">Saint Martin (Dutch part)</option><option value="MF">Saint Martin (French part)</option><option value="PM">Saint Pierre and Miquelon</option><option value="VC">Saint Vincent and the Grenadines</option><option value="SM">San Marino</option><option value="SA">Saudi Arabia</option><option value="SN">Senegal</option><option value="RS">Serbia</option><option value="SC">Seychelles</option><option value="SL">Sierra Leone</option><option value="SG">Singapore</option><option value="SK">Slovakia</option><option value="SI">Slovenia</option><option value="SB">Solomon Islands</option><option value="SO">Somalia</option><option value="ZA">South Africa</option><option value="GS">South Georgia/Sandwich Islands</option><option value="KR">South Korea</option><option value="SS">South Sudan</option><option value="ES">Spain</option><option value="LK">Sri Lanka</option><option value="SD">Sudan</option><option value="SR">Suriname</option><option value="SJ">Svalbard and Jan Mayen</option><option value="SZ">Swaziland</option><option value="SE">Sweden</option><option value="CH">Switzerland</option><option value="SY">Syria</option><option value="TW">Taiwan</option><option value="TJ">Tajikistan</option><option value="TZ">Tanzania</option><option value="TH">Thailand</option><option value="TL">Timor-Leste</option><option value="TG">Togo</option><option value="TK">Tokelau</option><option value="TO">Tonga</option><option value="TT">Trinidad and Tobago</option><option value="TN">Tunisia</option><option value="TR">Turkey</option><option value="TM">Turkmenistan</option><option value="TC">Turks and Caicos Islands</option><option value="TV">Tuvalu</option><option value="UG">Uganda</option><option value="UA">Ukraine</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom (UK)</option><option value="US">United States (US)</option><option value="UY">Uruguay</option><option value="UZ">Uzbekistan</option><option value="VU">Vanuatu</option><option value="VA">Vatican</option><option value="VE">Venezuela</option><option value="VN">Vietnam</option><option value="WF">Wallis and Futuna</option><option value="EH">Western Sahara</option><option value="WS">Western Samoa</option><option value="YE">Yemen</option><option value="ZM">Zambia</option><option value="ZW">Zimbabwe</option></select>  
	</span> 
	</p>--> 
	</div> 
	<p></p>  
	<p class="form-submit">  
	<input type="hidden" name="redirect_to" value="https://fluentthemes.com/wp/knowledge/">  
	<input type="submit" name="register" value="Signup" class="button color small submit">  
	<input type="hidden" name="form_type" value="ask-signup"></p> 
	</form>  
	</div> 
	</div>  
	
	<div class="infocenter-panel-pop" id="login-comments">
	    <h2>Login<i class="icon-remove"></i></h2>
	    <div class="form-style form-style-3">
	        <div class="ask_form inputs">
	            <form class="" action="<?=base_url('Home/signin')?>" method="post">
	                <div class="ask_error"></div>
	                <div class="form-inputs clearfix">
	                    <p class="login-text"> 
	                    <input class="required-item" type="text" value="" placeholde="email"
	                    onfocus="if (this.value == &#39;Username&#39;) {this.value = &#39;&#39;;}" 
	                    onblur="if (this.value == &#39;&#39;) {this.value = &#39;Username&#39;;}" name="email"> 
	                    <i class="icon-user"></i>
	                    </p>
	                    <p class="login-password"> 
	                    <input class="required-item" type="password" value="" placeholde="password" 
	                    onfocus="if (this.value == &#39;Password&#39;) {this.value = &#39;&#39;;}" 
	                    onblur="if (this.value == &#39;&#39;) {this.value = &#39;Password&#39;;}" name="pwd"> 
	                    <i class="icon-lock"></i> 
	                    <a href="https://fluentthemes.com/wp/knowledge/#">Forgot ?</a>
	                    </p>
	                    </div>
	                    
	                    <p class="form-submit login-submit"> 
	                    <span class="loader_2"></span> 
	                    <input type="submit" value="Log in" name="login" class="button color small login-submit submit sidebar_submit">
	                    </p>
	                    <div class="rememberme"> <label><input type="checkbox" name="rememberme" checked="checked"> Remember Me</label></div> <input type="hidden" name="redirect_to" value="https://fluentthemes.com/wp/knowledge/"> <input type="hidden" name="login_nonce" value="e824f0b952"> <input type="hidden" name="ajax_url" value="https://fluentthemes.com/wp/knowledge/wp-admin/admin-ajax.php"> <input type="hidden" name="form_type" value="ask-login"><div class="errorlogin"></div></form></div></div></div> 
	
	<div class="infocenter-panel-pop" id="lost-password">
	    <h2>Lost Password<i class="icon-remove"></i></h2>
	    <div class="form-style form-style-3">
	        <p>Enter your email to reset your password.</p><form method="post" class="ask-lost-password ask_form" action="https://fluentthemes.com/wp/knowledge/"><div class="ask_error"></div><div class="form-inputs clearfix"><p> <label for="user_mail_59" class="required">E-Mail<span>*</span></label> <input type="email" class="required-item" name="user_mail" id="user_mail_59"></p></div><p class="form-submit"> <input type="submit" value="Reset" class="button color small submit"> <input type="hidden" name="form_type" value="ask-forget"></p></form><div class="clearfix"></div></div></div><div id="wrap" class=" wrap-nicescroll">
	    