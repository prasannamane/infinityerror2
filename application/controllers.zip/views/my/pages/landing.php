	<div data-bg="url(https://fluentthemes.com/wp/knowledge/wp-content/uploads/2017/01/slider3.jpg)" class="section-warp infocenter-infotex rocket-lazyload" style="background-repeat: repeat; background-attachment: fixed; background-position: 0% 0%; background-image: url(&quot;https://fluentthemes.com/wp/knowledge/wp-content/uploads/2017/01/slider3.jpg&quot;);" data-was-processed="true">
	    <div class="container clearfix">
		<div class="box_icon box_warp box_no_border box_no_background">
			<div class="row">
				<div class="col-md-12">
					<h2>HAVE A QUESTION?</h2>
					<p>If you have any question you can ask below or enter what you are looking for!</p>
					<div class="clearfix"></div>
					<div class="clearfix"></div>
					<div>
						<div id="live-search">
							<div id="search-wrap">
								<form role="search" method="get" id="searchform" class="form-style form-style-2" action="https://fluentthemes.com/wp/knowledge/">
									<p> <input type="text" onfocus="if (this.value == this.defaultValue) {this.value = &#39;&#39;;}" onblur="if(this.value==&#39;&#39;)this.value=this.defaultValue;" value="Type your search terms here" name="s" id="s" autocapitalize="off" autocorrect="off" autocomplete="off"> 
										<i class="live-search-loading fa fa-spinner fa-spin"></i> 
										<button type="submit" id="searchsubmit" class="ask-question-new-class"> 
											<span class="color button small publish-question">Search</span> </button>
									</p>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>